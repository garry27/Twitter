<html>

<head>

	<title>Twitter</title>	

	<link rel="stylesheet" href="style.css" type="text/css" />

</head>



<body>

	<div id="header">

		<img src="image\mobimg.jpg" align="right"  height=280 width=280> </img>

		<br>
		<h1>&nbsp; &nbsp;Twitter</h1>
			  <h2>&nbsp; &nbsp; &nbsp; &nbsp; Tweet your heart out!<br> </h2>

		<ul>


<br> <br> <br> <br> <br> <br> <br><li><a href="login.htm">Login</a></li>

		</ul>	



	</div>

	<div id="content">

		<div id="sidebar">

			<h1>What's Twitter?</h1>

			<p> 
				<marquee  direction="up"><a href= 'http://en.wikipedia.org/wiki/Twitter' target = "_blank" >  <img src="image\mobimg.jpg" align = "center"  height=200 width=200> </img></a>	
				</marquee> 
			</p>

			<h1></h1>

			<ul>



			</ul>

			</div>

		<div id="main">

			<h1>Recover Password</h1>

			<p>


			<form name="signup" method="post" action="recoverpass.php" >
			

			<p><strong>User ID:<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong><input type="text" size="16" name="userid" value=""/></p>
			

			</p>
		     
  

		   	<p><input type="submit" value="Next"></p>

			</form>
<br> </br>
<b><center>Copyright. All rights reserved by UrbanMusic.Inc </center><br></b>                             

 

		       
</div>


</div>

</body>

</html>


<?php



?>