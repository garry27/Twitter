------------------------------------------Instruction for setting up Twitter website-------------------------------------------

Software needed

-Wamp Server 2.0 or higher (consisting of)
	1. php
	2. apache server
	3. mysql

-Install the wamp server.Copy paste the folder 'twitter' and 'index.php' in location C:\wamp\www\
-Make sure you overwrite the earlier index.php in the folder  www
-Create database using sql dump file in mysql for wamp (not in mysql installed in the system exclusively).
-The default user of mysql is 'root' and password is nothing i.e '' .
-Now type localhost or your IP address in the browser. The website will run.
-You can access the website anywhere in the local network by typing the IP address on which the wamp server is installed.


--------------------------------------------X-----------------------------------------------X---------------------------------------
