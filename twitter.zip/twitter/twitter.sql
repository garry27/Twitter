-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 15, 2013 at 05:16 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `twitter`
--

-- --------------------------------------------------------

--
-- Table structure for table `following`
--

CREATE TABLE IF NOT EXISTS `following` (
  `user_id` varchar(256) DEFAULT NULL,
  `following_id` varchar(256) DEFAULT NULL,
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `following`
--

INSERT INTO `following` (`user_id`, `following_id`) VALUES
('agni93', 'garry27'),
('garry27', 'agni93'),
('tesla_nikola', 'garry27'),
('garry27', 'tesla_nikola'),
('agni93', 'johri21'),
('saikr', 'agni93'),
('agni93', 'shubaham30'),
('johri21', 'agni93'),
('bravo', 'agni93'),
('bravo', 'shubaham30'),
('bravo', 'tesla_nikola'),
('bravo', 'karan30'),
('bravo', 'saikr'),
('agni93', 'tesla_nikola'),
('johri21', 'tesla_nikola'),
('agni93', 'bravo'),
('johri21', 'garry27'),
('tesla_nikola', 'shubaham30'),
('tesla_nikola', 'johri21'),
('tesla_nikola', 'agni93'),
('agni93', 'saikr'),
('tesla_nikola', 'karan30'),
('tesla_nikola', 'saikr'),
('tesla_nikola', 'bravo'),
('pran16', 'johri21'),
('pran16', 'garry27'),
('agni93', 'karan30'),
('saikr', 'johri21'),
('johri21', 'saikr'),
('johri21', 'pran16');

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `tweet_id` varchar(256) DEFAULT NULL,
  `user_id` varchar(256) DEFAULT NULL,
  `tag` varchar(256) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`tweet_id`, `user_id`, `tag`) VALUES
('9', 'agni93', 'mi'),
('8', 'agni93', 'mi'),
('7', 'agni93', 'rcb'),
('7', 'agni93', 'ipl'),
('1', 'saikr', 'mi'),
('2', 'saikr', 'mi'),
('3', 'saikr', 'ipl'),
('3', 'garry27', 'dbms'),
('3', 'garry27', 'os'),
('18', 'agni93', 'tweet..'),
('14', 'agni93', 'mi'),
('19', 'agni93', 'yipee...!!'),
('1', 'pran16', 'terminator'),
('2', 'pran16', 'mi'),
('2', 'johri21', 'yipee...!!'),
('5', 'garry27', 'ipl'),
('6', 'garry27', 'ipl'),
('7', 'garry27', 'yipee..!!\r\n'),
('17', 'agni93', 'ipl'),
('4', 'saikr', 'clab2'),
('21', 'agni93', 'terminator'),
('20', 'agni93', 'gks');

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE IF NOT EXISTS `topic` (
  `topic_id` varchar(256) NOT NULL DEFAULT '',
  `topic_name` varchar(256) NOT NULL,
  `topic_link` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`topic_id`, `topic_name`, `topic_link`) VALUES
('1', 'Facebook', 'http://www.facebook.com/'),
('2', 'IPL 2013', 'http://www.iplt20.com/'),
('3', 'Paulo Coelho', 'http://paulocoelho.com/en/'),
('4', 'The LNMIIT', 'http://www.lnmiit.ac.in/'),
('5', 'Shah Rukh Khan ', 'http://en.wikipedia.org/wiki/Shahrukh_Khan'),
('6', 'The Times of India', 'http://timesofindia.indiatimes.com/'),
('7', 'Weather', 'http://www.accuweather.com/en'),
('8', 'Indian Railways', 'https://www.irctc.co.in/'),
('9', 'Quora', 'http://www.quora.com/'),
('10', 'The Lord of The Rings', 'https://en.wikipedia.org/wiki/The_Lord_of_the_Rings'),
('11', 'Sachin Tendulkar', 'http://en.wikipedia.org/wiki/Sachin_Tendulkar');

-- --------------------------------------------------------

--
-- Table structure for table `tweet`
--

CREATE TABLE IF NOT EXISTS `tweet` (
  `tweet_id` int(5) NOT NULL DEFAULT '0',
  `user_id` varchar(256) NOT NULL DEFAULT '',
  `tweet_text` varchar(256) NOT NULL,
  `tweet_type` varchar(256) NOT NULL,
  PRIMARY KEY (`tweet_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tweet`
--

INSERT INTO `tweet` (`tweet_id`, `user_id`, `tweet_text`, `tweet_type`) VALUES
(1, 'agni93', 'hello', 'self'),
(2, 'agni93', 'number two???', 'self'),
(3, 'agni93', 'number three', 'self'),
(4, 'agni93', 'number 4', 'self'),
(5, 'agni93', 'number 5', 'self'),
(6, 'agni93', 'number 5', 'self'),
(7, 'agni93', 'tweet on #ipl and #rcb ', 'self'),
(1, 'garry27', 'hello', 'self'),
(2, 'garry27', 'bcbbcbc', 'self'),
(1, 'pran16', 'hey i am pranjal #terminator ', 'self'),
(1, 'karan30', 'hii', 'self'),
(1, 'tesla_nikola', 'hello', 'self'),
(8, 'agni93', ' #mi ', 'self'),
(9, 'agni93', '#mi ', 'self'),
(1, 'saikr', 'hello.. #mi fan ', 'self'),
(2, 'saikr', 'i love #mi ', 'self'),
(3, 'saikr', 'lets watch #ipl ', 'self'),
(3, 'garry27', 'tweet on #dbms and #os ', 'self'),
(19, 'agni93', 'english class over #yipee...!! ', 'self'),
(18, 'agni93', 'hey adding #tweet.. ', 'self'),
(11, 'agni93', 'hello gopi... ', 'retweet'),
(12, 'agni93', 'acm  icpc', 'retweet'),
(13, 'agni93', 'hello gopi... ', 'retweet'),
(14, 'agni93', 'hello.. #mi fan ', 'retweet'),
(1, 'johri21', 'hey.. ', 'self'),
(2, 'pran16', '#mi is my team ', 'retweet'),
(3, 'pran16', 'bcbbcbc', 'retweet'),
(15, 'agni93', 'hey.. ', 'self'),
(4, 'garry27', 'hey... ', 'self'),
(5, 'garry27', 'hey #ipl ', 'self'),
(6, 'garry27', 'hey #ipl ', 'self'),
(7, 'garry27', 'English class over #yipee..!!\r\n ', 'retweet'),
(17, 'agni93', 'hey #ipl ', 'self'),
(2, 'johri21', 'english class over #yipee...!! ', 'retweet'),
(1, '', '', 'retweet'),
(4, 'saikr', 'hey i am sai #clab2 ', 'self'),
(21, 'agni93', 'hey i am pranjal #terminator ', 'retweet'),
(20, 'agni93', '#gks ', 'self');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` varchar(256) NOT NULL DEFAULT '',
  `password` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `description` varchar(256) DEFAULT NULL,
  `follower_count` int(5) DEFAULT NULL,
  `following_count` int(5) DEFAULT NULL,
  `tweet_count` int(5) DEFAULT NULL,
  `sec_question` varchar(256) DEFAULT NULL,
  `sec_ans` varchar(256) DEFAULT NULL,
  `img_url` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `password`, `name`, `location`, `description`, `follower_count`, `following_count`, `tweet_count`, `sec_question`, `sec_ans`, `img_url`) VALUES
('agni93', '123', 'Ankur Agnihotri', 'Jaipur', 'Singer', 5, 7, 20, 'what is your lnmiit roll number', 'y11uc095', 'upload/agni93'),
('garry27', '123', 'Gaurav Kr Singh', 'Lucknow', 'Lost', 4, 2, 7, 'what is your lnmiit roll number', 'y11uc095', 'upload/garry27'),
('johri21', '789', 'Abhinav Johri', 'lucknow', 'programmer', 4, 5, 2, 'what is your lnmiit roll number', 'y11uc095', 'upload/johri21'),
('shubaham30', '123', 'Shubham Asthana', 'Singapore', 'lota', 3, 0, 0, 'what is your lnmiit roll number', 'y11uc095', 'upload/shubaham30'),
('tesla_nikola', '123', 'Anany Dwivedi', 'Jaipur', 'Tesla Fan', 4, 7, 1, 'Where was tesla born', 'smiljan', 'upload/tesla_nikola'),
('karan30', '123', 'Karan Bhargava', 'Jaipur', 'Alien', 3, 0, 1, 'what is your lnmiit roll number', 'y11uc095', 'upload/karan30'),
('saikr', 'sai', 'Sai Krishna', 'jhansi', 'quizzer', 4, 2, 4, 'room no.', 'c 010', 'upload/saikr'),
('bravo', '123', 'Tarun Krishna', 'Sultanpur', 'a', 2, 5, 0, 'a', 'a', 'upload/bravo'),
('pran16', '123', 'Pranjal Successena', 'Bhopal', 'Terminator', 1, 2, 3, 'your hss in 4th sem', 'logic', 'upload/pran16'),
('ad14', '123', 'Aditya Deswal', 'Agra', 'Philospher', 0, 0, 0, 'hobby', 'sleeping', 'upload/ad14');

-- --------------------------------------------------------

--
-- Table structure for table `user_topic`
--

CREATE TABLE IF NOT EXISTS `user_topic` (
  `user_id` varchar(256) DEFAULT NULL,
  `topic_id` varchar(256) DEFAULT NULL,
  KEY `user_id` (`user_id`),
  KEY `topic_id` (`topic_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_topic`
--

INSERT INTO `user_topic` (`user_id`, `topic_id`) VALUES
('tesla_nikola', '1'),
('johri21', '1'),
('agni93', '1'),
('saikr', '1'),
('garry27', '1'),
('garry27', '4'),
('agni93', '5'),
('johri21', '2'),
('agni93', '9'),
('johri21', '3'),
('agni93', ''),
('agni93', '11'),
('shubaham30', '1'),
('shubaham30', '9'),
('shubaham30', '8'),
('shubaham30', '10'),
('shubaham30', '11');
