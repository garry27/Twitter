<?php 

header( 'Location: twitter/login.htm' ) ; 

?> 